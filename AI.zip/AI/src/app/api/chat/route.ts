import { NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

// Session memory to maintain conversation context
const sessionMemory = new Map<string, Array<{role: string, content: string}>>

export async function POST(request: Request) {
  try {
    const { message, sessionId = 'default' } = await request.json()

    if (!message) {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 })
    }

    // Get or create session memory
    if (!sessionMemory.has(sessionId)) {
      sessionMemory.set(sessionId, [])
    }

    const conversation = sessionMemory.get(sessionId)!

    // Add user message to conversation
    conversation.push({ role: 'user', content: message })

    // Keep only last 10 messages to maintain context
    if (conversation.length > 10) {
      conversation.splice(0, conversation.length - 10)
    }

    // Create ZAI instance
    const zai = await ZAI.create()

    // System prompt for AADARSHAI personality
    const systemPrompt = `You are AADARSHAI, a friendly, intelligent, calm, supportive, and motivating AI assistant. 

Your personality traits:
- Friendly and approachable, like chatting with a real human
- Intelligent and knowledgeable but humble
- Calm and patient in your responses
- Supportive and encouraging
- Motivating and positive

Conversation style:
- Natural, conversational replies
- Ask smart follow-up questions when appropriate
- Maintain context throughout the conversation
- Use clear, simple language that's easy to understand
- Be encouraging and positive
- Avoid robotic or overly formal language

For mathematical expressions:
- Use clean, human-readable formatting
- Examples: √16 = 4, 5² = 25, 12 ÷ 3 = 4
- Avoid programming syntax or unreadable symbols
- Make it easy for students to understand

Always respond in a way that feels natural and supportive, like a helpful friend who happens to be very knowledgeable.`

    // Prepare messages for API
    const messages = [
      { role: 'system', content: systemPrompt },
      ...conversation
    ]

    // Get AI response
    const completion = await zai.chat.completions.create({
      messages,
      temperature: 0.7,
      max_tokens: 500,
    })

    const aiResponse = completion.choices[0]?.message?.content || "I'm sorry, I couldn't generate a response."

    // Add AI response to conversation
    conversation.push({ role: 'assistant', content: aiResponse })

    return NextResponse.json({ response: aiResponse })

  } catch (error) {
    console.error('Chat API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}